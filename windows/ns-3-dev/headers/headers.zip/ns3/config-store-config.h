/* WARNING! All changes made to this file will be lost! */

#ifndef W_NS3_CONFIG_STORE_CONFIG_H_WAF
#define W_NS3_CONFIG_STORE_CONFIG_H_WAF

#define PYTHONDIR "/usr/local/lib/python2.7/site-packages"
#define PYTHONARCHDIR "/usr/local/lib/python2.7/site-packages"
#define HAVE_PYTHON_H 1

#endif /* W_NS3_CONFIG_STORE_CONFIG_H_WAF */
